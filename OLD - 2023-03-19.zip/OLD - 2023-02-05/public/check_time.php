<?php
date_default_timezone_set('Asia/Manila');
    $server_time=date('Y-m-d H:i:s');
	echo "$server_time";
?>
