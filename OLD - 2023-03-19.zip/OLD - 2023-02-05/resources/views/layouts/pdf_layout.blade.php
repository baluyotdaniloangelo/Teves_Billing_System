@include('layouts.pdf_header')
</head>

<body class="">
@yield('content')
 

</body>

</html>